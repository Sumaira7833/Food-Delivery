let currentOrder = null;

function placeOrder(order) {
  currentOrder = {
    ...order,
    driver: "Driver A",
    status: "Pending"
  };
}

function getAssignedOrder() {
  return currentOrder;
}

function updateStatus(newStatus) {
  if (currentOrder) {
    currentOrder.status = newStatus;
  }
}

module.exports = { placeOrder, getAssignedOrder, updateStatus };
