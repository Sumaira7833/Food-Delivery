const express = require('express');
const path = require('path');
const app = express();
const PORT = 3000;

const state = require('./order');

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public'));

// 🏠 Welcome Page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// 🔐 Login Page
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// 🚪 Login Logic
app.post('/login', (req, res) => {
  const role = req.body.role;
  if (role === 'Admin') return res.redirect('/admin');
  if (role === 'Customer') return res.redirect('/customer');
  if (role === 'Driver') return res.redirect('/driver');
  res.send("Invalid role selected");
});

// 🧑 Admin Page
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// 🧺 Customer Page
app.get('/customer', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'customer.html'));
});

// 🚚 Driver Page (includes centered logo if no order)
app.get('/driver', (req, res) => {
  const order = state.getAssignedOrder();

  let html = `<h2 style="text-align:center; color:#065f46;">Driver Panel</h2>`;

  if (order) {
    html += `
    <div class='card'>
      <h3>Assigned Order</h3>
      <p><strong>Customer:</strong> ${order.name}</p>
      <p><strong>Address:</strong> ${order.address}</p>
      <p><strong>Phone:</strong> ${order.phone}</p>
      <p><strong>Product:</strong> ${order.product}</p>
      <p><strong>Quantity:</strong> ${order.quantity}</p>
      <p><strong>Status:</strong> ${order.status}</p>
      <form action="/update-status" method="POST">
        <select name="status" required>
          <option value="Delivered">Delivered</option>
          <option value="In Transit">In Transit</option>
        </select>
        <button type="submit">Update Status</button>
      </form>
    </div>`;
  } else {
    html += `
    <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 70vh;">
      <p style="font-size: 20px; color: #444;">No orders assigned yet.</p>
      <img src="/images/logo.PNG" alt="Logo" style="width: 250px; margin-top: 20px;">
    </div>`;
  }

  res.send(`<!DOCTYPE html>
  <html>
  <head>
    <title>Driver</title>
    <link rel="stylesheet" href="/style.css">
  </head>
  <body class="container logo-bg">
    ${html}
  </body>
  </html>`);
});

// 📝 Place Order
app.post('/place-order', (req, res) => {
  state.placeOrder(req.body);
  res.send('<h2>Order placed! Admin has assigned a driver.</h2><a href="/">← Back to Home</a>');
});

// 🔄 Update Status
app.post('/update-status', (req, res) => {
  state.updateStatus(req.body.status);
  res.redirect('/driver');
});

app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});
